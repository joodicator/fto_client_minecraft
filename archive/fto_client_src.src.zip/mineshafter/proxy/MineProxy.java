/*     */ package mineshafter.proxy;
/*     */ 
/*     */ import com.sun.net.httpserver.Headers;
/*     */ import com.sun.net.httpserver.HttpExchange;
/*     */ import com.sun.net.httpserver.HttpHandler;
/*     */ import com.sun.net.httpserver.HttpServer;
/*     */ import com.sun.net.httpserver.HttpsConfigurator;
/*     */ import com.sun.net.httpserver.HttpsServer;
/*     */ import java.io.IOException;
/*     */ import java.io.OutputStream;
/*     */ import java.io.PrintStream;
/*     */ import java.net.HttpURLConnection;
/*     */ import java.net.InetSocketAddress;
/*     */ import java.net.Proxy;
/*     */ import java.net.URI;
/*     */ import java.net.URL;
/*     */ import java.net.UnknownHostException;
/*     */ import java.security.KeyStore;
/*     */ import java.util.List;
/*     */ import java.util.Map;
/*     */ import javax.net.ssl.KeyManagerFactory;
/*     */ import javax.net.ssl.SSLContext;
/*     */ import javax.net.ssl.TrustManagerFactory;
/*     */ import mineshafter.util.Resources;
/*     */ import mineshafter.util.Streams;
/*     */ 
/*     */ public class MineProxy
/*     */ {
/*  22 */   public static float version = 0.0F;
/*  23 */   public static int port = 0;
/*  24 */   public static int httpport = 0;
/*  25 */   public static int httpsport = 0;
/*  26 */   public static String authServer = Resources.loadString("auth");
/*  27 */   public static String skinServer = authServer;
/*  28 */   public static URLRewriter[] rewriters = null;
/*     */ 
/*     */   public static void listen(int port, int httpport, int httpsport, float version) throws UnknownHostException, IOException {
/*  31 */     listen(port, httpport, httpsport, version, null);
/*     */   }
/*     */ 
/*     */   public static void listen(int port, int httpport, int httpsport, float version, String authServer) throws UnknownHostException, IOException {
/*     */     try {
/*  36 */       if (authServer != null) {
/*  37 */         skinServer = MineProxy.authServer = authServer;
/*     */       }
/*     */ 
/*  40 */       rewriters = new URLRewriter[] { 
/*  42 */         new URLRewriter("http://s3\\.amazonaws\\.com/MinecraftSkins/(.+?)\\.png", 
/*  43 */         "http://" + skinServer + "/game/getskin.php?name=%s"), 
/*  45 */         new URLRewriter("http://s3\\.amazonaws\\.com/MinecraftCloaks/(.+?)\\.png", 
/*  46 */         "http://" + authServer + "/game/getcloak.php?user=%s"), 
/*  48 */         new URLRewriter("http://www\\.minecraft\\.net/game/(.*)", 
/*  49 */         "http://" + authServer + "/game/%s"), 
/*  51 */         new URLRewriter("http://session\\.minecraft\\.net/game/(.*)", 
/*  52 */         "http://" + authServer + "/game/%s") };
/*     */ 
/*  55 */       version = version;
/*  56 */       port = port;
/*  57 */       httpport = httpport;
/*  58 */       httpsport = httpsport;
/*     */ 
/*  63 */       KeyStore ks = KeyStore.getInstance("JKS");
/*  64 */       char[] pass = "password".toCharArray();
/*  65 */       ks.load(Resources.load("keys.jks"), pass);
/*  66 */       KeyManagerFactory kmf = KeyManagerFactory.getInstance("SunX509");
/*  67 */       TrustManagerFactory tmf = TrustManagerFactory.getInstance("SunX509");
/*  68 */       kmf.init(ks, pass);
/*  69 */       tmf.init(ks);
/*     */ 
/*  71 */       SSLContext context = SSLContext.getInstance("TLS");
/*  72 */       context.init(kmf.getKeyManagers(), tmf.getTrustManagers(), null);
/*  73 */       HttpServer server = HttpServer.create(new InetSocketAddress(port), 4);
/*  74 */       server.createContext("/", new ProxyHandler());
/*  75 */       server.setExecutor(null);
/*     */ 
/*  77 */       server.start();
/*     */ 
/*  79 */       HttpsServer sslserver = HttpsServer.create(new InetSocketAddress(httpsport), 4);
/*  80 */       sslserver.setHttpsConfigurator(new HttpsConfigurator(context));
/*  81 */       sslserver.createContext("/", new ProxyHandler());
/*  82 */       sslserver.setExecutor(null);
/*     */ 
/*  84 */       sslserver.start();
/*     */     }
/*     */     catch (Exception e)
/*     */     {
/* 122 */       System.out.println("Proxy starting error:");
/*     */     }
/*     */   }
/*     */ 
/*     */   public static String RewriteURL(String u)
/*     */   {
/*     */     try
/*     */     {
/* 140 */       for (URLRewriter ur : rewriters) {
/* 141 */         String newurl = ur.MatchAndReplace(u);
/* 142 */         if (newurl != null) {
/* 143 */           u = newurl;
/* 144 */           break;
/*     */         }
/*     */       }
/*     */ 
/* 148 */       if (new URL(u).getPath().endsWith("/game/getversion.php"))
/* 149 */         u = u + "?proxy=" + Float.toString(version);
/*     */     }
/*     */     catch (Exception e) {
/* 152 */       System.out.println("URL couldn't be rewritten:");
/*     */     }
/*     */ 
/* 155 */     return u;
/*     */   }
/*     */ 
/*     */   public static class ProxyHandler
/*     */     implements HttpHandler
/*     */   {
/*     */     public void handle(HttpExchange t)
/*     */       throws IOException
/*     */     {
/* 164 */       String method = t.getRequestMethod();
/* 165 */       String url = makeURL(t);
/* 166 */       String murl = MineProxy.RewriteURL(url);
/*     */ 
/* 168 */       System.out.println("Request: " + method + " " + url + "\nWill go to " + murl);
/*     */ 
/* 170 */       URL urlm = new URL(murl);
/* 171 */       String host = urlm.getHost();
/*     */ 
/* 173 */       boolean post = method.equalsIgnoreCase("POST");
/*     */ 
/* 175 */       HttpURLConnection c = (HttpURLConnection)new URL(murl).openConnection(Proxy.NO_PROXY);
/* 176 */       c.setRequestMethod(method);
/*     */ 
/* 178 */       if (post) {
/* 179 */         c.setDoOutput(true);
/*     */       }
/*     */ 
/* 182 */       transferHeaders(t, c, host);
/*     */ 
/* 184 */       if (post) {
/* 185 */         Streams.pipeStreams(t.getRequestBody(), c.getOutputStream());
/*     */       }
/*     */ 
/* 188 */       transferHeaders(c, t);
/* 189 */       int contentLength = c.getContentLength();
/*     */ 
/* 191 */       if (contentLength == -1) {
/* 192 */         String encoding = (String)((List)c.getHeaderFields().get("Transfer-Encoding")).get(0);
/*     */ 
/* 194 */         if (encoding.equalsIgnoreCase("chunked")) {
/* 195 */           contentLength = 0;
/*     */         }
/*     */       }
/*     */ 
/* 199 */       System.out.println("resp: " + c.getResponseCode() + ", len: " + contentLength);
/*     */ 
/* 201 */       t.sendResponseHeaders(c.getResponseCode(), contentLength);
/* 202 */       OutputStream out = t.getResponseBody();
/*     */ 
/* 204 */       Streams.pipeStreams(c.getInputStream(), out);
/* 205 */       out.close();
/*     */     }
/*     */ 
/*     */     protected void transferHeaders(HttpExchange t, HttpURLConnection c, String host)
/*     */     {
/* 223 */       Headers headers = t.getRequestHeaders();
/*     */ 
/* 225 */       for (String h : headers.keySet())
/* 226 */         if (h != null)
/*     */         {
/* 230 */           if (h.equalsIgnoreCase("host"))
/* 231 */             c.setRequestProperty(h, host);
/*     */           else
/* 233 */             c.setRequestProperty(h, headers.getFirst(h));
/*     */         }
/*     */     }
/*     */ 
/*     */     protected void transferHeaders(HttpURLConnection c, HttpExchange t)
/*     */     {
/* 239 */       Map serverHeaders = c.getHeaderFields();
/* 240 */       Headers clientHeaders = t.getResponseHeaders();
/*     */ 
/* 242 */       for (String h : serverHeaders.keySet())
/* 243 */         if (h != null)
/*     */         {
/* 247 */           clientHeaders.put(h, (List)serverHeaders.get(h));
/*     */         }
/*     */     }
/*     */ 
/*     */     protected String makeURL(HttpExchange t) {
/* 252 */       URI uri = t.getRequestURI();
/* 253 */       String host = uri.getHost();
/*     */ 
/* 255 */       if (host == null) {
/* 256 */         host = t.getRequestHeaders().getFirst("host");
/*     */       }
/*     */ 
/* 259 */       String path = uri.getPath();
/*     */ 
/* 261 */       if (uri.getQuery() != null) {
/* 262 */         path = path + "?" + uri.getQuery();
/*     */       }
/*     */ 
/* 266 */       String url = uri.getScheme();
/*     */ 
/* 268 */       if (url == null)
/* 269 */         url = "http://";
/*     */       else {
/* 271 */         url = url + "://";
/*     */       }
/*     */ 
/* 274 */       url = url + host + path;
/*     */ 
/* 276 */       return url;
/*     */     }
/*     */   }
/*     */ }

/* Location:           /home/joseph/mc/fto_client_src/
 * Qualified Name:     mineshafter.proxy.MineProxy
 * JD-Core Version:    0.6.2
 */